pub mod pdf;
pub mod adv_loss;
pub mod generator;
pub mod discriminator;