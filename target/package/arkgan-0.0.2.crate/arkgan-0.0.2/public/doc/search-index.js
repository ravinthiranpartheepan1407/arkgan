var searchIndex = new Map(JSON.parse('[\
["arkgan",{"doc":"","t":"CH","n":["pdf","calc_pdf"],"q":[[0,"arkgan"],[1,"arkgan::pdf"],[2,"alloc::vec"]],"d":["",""],"i":[0,0],"f":"`{{{d{b}}}{{f{b}}}}","c":[],"p":[[1,"f64"],[1,"slice"],[5,"Vec",2]],"b":[]}]\
]'));
if (typeof exports !== 'undefined') exports.searchIndex = searchIndex;
else if (window.initSearch) window.initSearch(searchIndex);
